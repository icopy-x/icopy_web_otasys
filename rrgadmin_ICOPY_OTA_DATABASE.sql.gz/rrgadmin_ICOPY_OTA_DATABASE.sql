-- MySQL dump 10.13  Distrib 5.7.41, for Linux (x86_64)
--
-- Host: localhost    Database: rrgadmin_ICOPY_OTA_DATABASE
-- ------------------------------------------------------
-- Server version	5.7.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ota_job_list`
--

DROP TABLE IF EXISTS `ota_job_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ota_job_list` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `HASH` varchar(32) NOT NULL,
  `PROGRESS` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ota_job_list`
--

LOCK TABLES `ota_job_list` WRITE;
/*!40000 ALTER TABLE `ota_job_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `ota_job_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ota_sys_maintenance_state`
--

DROP TABLE IF EXISTS `ota_sys_maintenance_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ota_sys_maintenance_state` (
  `id` int(11) NOT NULL,
  `STATE` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ota_sys_maintenance_state`
--

LOCK TABLES `ota_sys_maintenance_state` WRITE;
/*!40000 ALTER TABLE `ota_sys_maintenance_state` DISABLE KEYS */;
INSERT INTO `ota_sys_maintenance_state` (`id`, `STATE`) VALUES (0,0);
/*!40000 ALTER TABLE `ota_sys_maintenance_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usr_ota_requests`
--

DROP TABLE IF EXISTS `usr_ota_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usr_ota_requests` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) NOT NULL,
  `HASH` varchar(32) NOT NULL,
  `DEVICE_SN` varchar(8) NOT NULL,
  `ADD_TIME` datetime NOT NULL,
  `CURRENT_STATE` int(1) NOT NULL DEFAULT '0',
  `OK_TIME` datetime DEFAULT NULL,
  `ISWAITING` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4778 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usr_ota_requests`
--

LOCK TABLES `usr_ota_requests` WRITE;
/*!40000 ALTER TABLE `usr_ota_requests` DISABLE KEYS */;
INSERT INTO `usr_ota_requests` (`ID`, `EMAIL`, `HASH`, `DEVICE_SN`, `ADD_TIME`, `CURRENT_STATE`, `OK_TIME`, `ISWAITING`) VALUES (4773,'alexpit881@gmail.com','41692a46fa012377690ca592d8622c84','07010045','2023-03-13 19:24:09',1,'2023-03-13 19:25:03',0),(4772,'acidprime@wallcity.org','20228800fa0c7da56fc5c93e01cff834','04410004','2023-03-13 15:25:12',1,'2023-03-13 15:26:03',0),(4771,'l.donaubauer@sec-consult.com','36760590904678b66074080447b5aaa1','01920029','2023-03-13 13:40:40',1,'2023-03-13 13:41:33',0),(4770,'943938644@qq.com','01f4aef929b5cd2bead34cb6ff8a99b8','06450016','2023-03-13 09:26:58',1,'2023-03-13 09:27:51',0),(4769,'deraskg19@gmail.com','d54444fac2552cdcd85b535178198734','03040258','2023-03-13 07:19:37',1,'2023-03-13 07:20:40',0),(4777,'64101226@qq.com','06af9f4c035efcd0a7861be600ebba34','00210003','2023-03-20 01:10:24',1,'2023-03-20 01:11:08',0),(4768,'donald.springstead@gmail.com','2e3b5ba8366f8919d8a8448d74e1c245','01650021','2023-03-13 06:23:20',1,'2023-03-13 06:24:14',0),(4767,'ceshi@icopy-x.com','327ff6ed8086e459f5d53d41c73f1ef3','04240023','2023-03-13 05:52:34',1,'2023-03-13 05:53:27',0),(4766,'2410606214@qq.com','e619197df2272dc13d552c694939c659','04240044','2023-03-13 00:57:12',1,'2023-03-13 00:57:58',0),(4765,'zsjnaoc@gmail.com','695b85a6abced4ea576e051e74dd2931','05140029','2023-03-13 00:46:12',1,'2023-03-13 00:47:08',0),(4764,'aj56433465@gmail.com','c172259a13c0a17b9daa82cc97805868','02250019','2023-03-12 23:12:22',1,'2023-03-12 23:13:19',0),(4763,'116168585@qq.com','2a1be3c774300de72b939d9317eed67d','06450013','2023-03-12 07:36:40',1,'2023-03-12 07:43:27',0),(4762,'wayne.norwich@gmail.com','5a393c93e3a076e35d53457aa9f03247','02420047','2023-03-11 07:23:04',1,'2023-03-11 07:23:58',0),(4776,'filippov.pavel.alexandrovich@gmail.com','c7ecf7754fb7f06a3d3014d70d566d05','06890051','2023-03-14 11:33:04',1,'2023-03-14 11:34:14',0),(4775,'clintonhillhardware@gmail.com','dfa2712427393ed2f4ac01ab5917c5d1','04420020','2023-03-14 10:54:39',1,'2023-03-14 10:55:35',0),(4774,'caleche@msn.cn','d6417acfbceef98e7da437af2f452ca5','04240007','2023-03-14 09:36:06',1,'2023-03-14 09:37:01',0);
/*!40000 ALTER TABLE `usr_ota_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'rrgadmin_ICOPY_OTA_DATABASE'
--

--
-- Dumping routines for database 'rrgadmin_ICOPY_OTA_DATABASE'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-20  2:06:19
